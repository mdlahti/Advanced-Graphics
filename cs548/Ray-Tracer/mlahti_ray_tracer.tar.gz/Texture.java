
public abstract class Texture {
	// abstract texture class for simple texture, image texture, marble texture, etc.
	public Texture(){}
	
	abstract Vector getColor(Vector p);
}
