RayTracer.java

How to Run: java RayTracer <imagename.ppm>

Will ray trace planes, spheres, triangles, bezier curves and teapots.
Currently handles shadows, reflections, refractions, single 
color textures, marbled textures, and random stratified multi-sampling.

Partially implemented: variations of marble texture and 2-D image textures.

Currently set up to create an image of a marbled teapot.
