
public class Vec8 {
	public Vector A,B,C,D,E,F,G,H;
	
	// an 8 vector container for subdividing Bezier patches
	public Vec8(Vector a, Vector b, Vector c, Vector d,Vector e, Vector f, Vector g, Vector h){
		this.A = a;
		this.B = b;
		this.C = c;
		this.D = d;
		this.E = e;
		this.F = f;
		this.G = g;
		this.H = h;
	}
}
